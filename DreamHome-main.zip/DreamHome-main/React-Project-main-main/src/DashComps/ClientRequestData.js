//ClientRequestData.js

const clientRequestData = [
    { id: 11, name: 'Michael Brown', profession: 'Contractor' },
    { id: 12, name: 'Olivia Smith', profession: 'Interior Designer' },
    { id: 13, name: 'David Johnson', profession: 'Architect' },
    { id: 14, name: 'Sophia Williams', profession: 'Contractor' },
    { id: 15, name: 'William Davis', profession: 'Interior Designer' },
    { id: 16, name: 'Emma Miller', profession: 'Architect' },
    { id: 17, name: 'Alexander Wilson', profession: 'Contractor' },
    { id: 18, name: 'Victoria Taylor', profession: 'Interior Designer' },
    { id: 19, name: 'Daniel Clark', profession: 'Architect' },
    { id: 20, name: 'Ava Johnson', profession: 'Contractor' },
];

export default clientRequestData;